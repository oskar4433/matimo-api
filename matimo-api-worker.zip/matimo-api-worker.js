const ALLOWED_ORIGINS = new Set([
  "https://matimoegitim.com",
  "https://www.matimoegitim.com",
]);

export default {
  async fetch(request, env) {
    const origin = request.headers.get("Origin") || "";
    const cors = corsHeaders(origin);
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });

    try {
      if (!env.DB) return json({ error: "D1 bağlantısı bulunamadı. Değişken adı DB olmalı." }, 500, cors);
      await ensureSchema(env.DB);
      const url = new URL(request.url);
      const path = url.pathname.replace(/\/$/, "") || "/";

      if (request.method === "GET" && path === "/") return json({ ok: true, service: "Matimo API" }, 200, cors);
      if (request.method === "POST" && path === "/api/register") return register(request, env.DB, cors);
      if (request.method === "POST" && path === "/api/login") return login(request, env.DB, cors);
      if (request.method === "GET" && path === "/api/me") return getMe(request, env.DB, cors);
      if (request.method === "POST" && path === "/api/logout") return logout(request, env.DB, cors);
      if (request.method === "POST" && path === "/api/progress") return saveProgress(request, env.DB, cors);
      if (request.method === "GET" && path === "/api/progress") return getProgress(request, env.DB, cors);
      return json({ error: "Adres bulunamadı." }, 404, cors);
    } catch (error) {
      return json({ error: "Sunucu hatası oluştu.", detail: String(error.message || error) }, 500, cors);
    }
  },
};

function corsHeaders(origin) {
  const headers = {
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Max-Age": "86400",
  };
  if (ALLOWED_ORIGINS.has(origin)) {
    headers["Access-Control-Allow-Origin"] = origin;
    headers.Vary = "Origin";
  }
  return headers;
}

function json(data, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json; charset=UTF-8", ...extraHeaders },
  });
}

async function readBody(request) {
  try { return await request.json(); } catch { return {}; }
}

const normalizeEmail = (value) => String(value || "").trim().toLowerCase();

async function ensureSchema(db) {
  await db.batch([
    db.prepare(`CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL,
      password_salt TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )`),
    db.prepare(`CREATE TABLE IF NOT EXISTS sessions (
      token TEXT PRIMARY KEY, user_id INTEGER NOT NULL, expires_at TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )`),
    db.prepare(`CREATE TABLE IF NOT EXISTS progress (
      id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
      game_id TEXT NOT NULL, score INTEGER NOT NULL DEFAULT 0,
      correct_count INTEGER NOT NULL DEFAULT 0, wrong_count INTEGER NOT NULL DEFAULT 0,
      completed INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(user_id, game_id), FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )`),
  ]);
}

async function register(request, db, cors) {
  const body = await readBody(request);
  const name = String(body.name || body.fullName || "").trim();
  const email = normalizeEmail(body.email);
  const password = String(body.password || "");
  if (name.length < 2) return json({ error: "Ad en az 2 karakter olmalı." }, 400, cors);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return json({ error: "Geçerli bir e-posta adresi girin." }, 400, cors);
  if (password.length < 6) return json({ error: "Şifre en az 6 karakter olmalı." }, 400, cors);
  const existing = await db.prepare("SELECT id FROM users WHERE email = ?").bind(email).first();
  if (existing) return json({ error: "Bu e-posta adresi zaten kayıtlı." }, 409, cors);
  const salt = randomToken(16);
  const passwordHash = await hashPassword(password, salt);
  const result = await db.prepare("INSERT INTO users (name, email, password_hash, password_salt) VALUES (?, ?, ?, ?)")
    .bind(name, email, passwordHash, salt).run();
  const userId = result.meta.last_row_id;
  const token = await createSession(db, userId);
  return json({ ok: true, token, user: { id: userId, name, email } }, 201, cors);
}

async function login(request, db, cors) {
  const body = await readBody(request);
  const email = normalizeEmail(body.email);
  const password = String(body.password || "");
  const user = await db.prepare("SELECT id, name, email, password_hash, password_salt FROM users WHERE email = ?").bind(email).first();
  if (!user || await hashPassword(password, user.password_salt) !== user.password_hash)
    return json({ error: "E-posta veya şifre hatalı." }, 401, cors);
  const token = await createSession(db, user.id);
  return json({ ok: true, token, user: { id: user.id, name: user.name, email: user.email } }, 200, cors);
}

async function getMe(request, db, cors) {
  const user = await authenticate(request, db);
  return user ? json({ ok: true, user }, 200, cors) : json({ error: "Oturum bulunamadı." }, 401, cors);
}

async function logout(request, db, cors) {
  const token = getBearerToken(request);
  if (token) await db.prepare("DELETE FROM sessions WHERE token = ?").bind(token).run();
  return json({ ok: true }, 200, cors);
}

async function saveProgress(request, db, cors) {
  const user = await authenticate(request, db);
  if (!user) return json({ error: "Oturum bulunamadı." }, 401, cors);
  const body = await readBody(request);
  const gameId = String(body.gameId || body.game_id || "").trim();
  if (!gameId) return json({ error: "Oyun bilgisi eksik." }, 400, cors);
  await db.prepare(`INSERT INTO progress (user_id, game_id, score, correct_count, wrong_count, completed, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
    ON CONFLICT(user_id, game_id) DO UPDATE SET score=MAX(progress.score, excluded.score),
    correct_count=MAX(progress.correct_count, excluded.correct_count), wrong_count=excluded.wrong_count,
    completed=MAX(progress.completed, excluded.completed), updated_at=CURRENT_TIMESTAMP`)
    .bind(user.id, gameId, safeInteger(body.score), safeInteger(body.correctCount ?? body.correct_count),
      safeInteger(body.wrongCount ?? body.wrong_count), body.completed ? 1 : 0).run();
  return json({ ok: true }, 200, cors);
}

async function getProgress(request, db, cors) {
  const user = await authenticate(request, db);
  if (!user) return json({ error: "Oturum bulunamadı." }, 401, cors);
  const result = await db.prepare(`SELECT game_id AS gameId, score, correct_count AS correctCount,
    wrong_count AS wrongCount, completed, updated_at AS updatedAt FROM progress
    WHERE user_id = ? ORDER BY updated_at DESC`).bind(user.id).all();
  return json({ ok: true, progress: (result.results || []).map(item => ({ ...item, completed: Boolean(item.completed) })) }, 200, cors);
}

async function authenticate(request, db) {
  const token = getBearerToken(request);
  if (!token) return null;
  await db.prepare("DELETE FROM sessions WHERE expires_at <= CURRENT_TIMESTAMP").run();
  return await db.prepare(`SELECT users.id, users.name, users.email FROM sessions
    INNER JOIN users ON users.id = sessions.user_id
    WHERE sessions.token = ? AND sessions.expires_at > CURRENT_TIMESTAMP`).bind(token).first() || null;
}

function getBearerToken(request) {
  const match = (request.headers.get("Authorization") || "").match(/^Bearer\s+(.+)$/i);
  return match ? match[1].trim() : "";
}

async function createSession(db, userId) {
  const token = randomToken(32);
  await db.prepare("INSERT INTO sessions (token, user_id, expires_at) VALUES (?, ?, datetime('now', '+30 days'))")
    .bind(token, userId).run();
  return token;
}

function safeInteger(value) {
  const number = Number(value);
  return Number.isFinite(number) ? Math.max(0, Math.round(number)) : 0;
}

function randomToken(byteLength) {
  const bytes = new Uint8Array(byteLength);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, byte => byte.toString(16).padStart(2, "0")).join("");
}

async function hashPassword(password, salt) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(`${salt}:${password}`));
  return Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, "0")).join("");
}
